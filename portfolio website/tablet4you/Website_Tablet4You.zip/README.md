TABLET4YOU

Doel:
Tijdens dit project werkt de student aan het verbeteren van een vooraf geprogrammeerde website.
Het project is een introductie. Het laat de student de vele facetten zien van applicatie ontwikkeling.
Een functioneel ontwerp, een plan van aanpak en uiteraard code.

Omschrijving:
Een vriendin van een van jouw projectbegeleiders – Fatima el Marsi – heeft een telefoon- en tablet-shop voor de zakelijke markt op internet. 
De helpdesk van deze site krijgt veel mails van mensen die niet goed weten welke tablet ze moeten kopen, 
meestal hebben ze niet zo veel verstand van techniek. Vaak gaat het om wat oudere mensen.

Fatima wil deze mensen graag goed helpen en heeft het idee opgevat om een verbetering van de site te laten ontwikkelen die (oudere) mensen wegwijs
maakt in de wereld van tablets. Zij hoopt dat de app mensen helpt om een goede keuze te maken voor een tablet uit zijn winkel. 
Ook wil zij graag dat zijn helpdesk wat minder mails krijgt over dit onderwerp.

Zij is er erg druk mee en heeft jou gevraagd om een opzet (een prototype) van een web app voor het kiezen van de juiste tablet maken.

De app gaat tablet4you heten en moet als volgt zijn opgebouwd:

· Home:

o de startpagina van de app met het logo van zijn bedrijf

o een aantal keuzevelden voor verschillende specificaties van tablets

· Lijst:

o Een lijst van alle beschikbare tablets, waarvan de meest geschikte bovenaan staat

Jouw opdrachtgever heeft dus wel een idee hoe de app eruit moet zien, maar vraagt jou om hem een voorstel voor de ‘lay-out’ te doen. 




## Ondersteuning & Documentation

Voor meer informatie kun je naar deze webpagina gaan:

